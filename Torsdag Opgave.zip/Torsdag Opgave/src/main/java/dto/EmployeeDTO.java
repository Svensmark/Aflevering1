/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dto;

import entities.Employee;

/**
 *
 * @author Emil PC
 */
public class EmployeeDTO {
    
    private int employeeID;
    private String employeeNAME;
    private String employeeADDRESS;

    public EmployeeDTO(Employee emp) {
        this.employeeID = emp.getId();
        this.employeeNAME = emp.getName();
        this.employeeADDRESS = emp.getAddress();
    }

    public int getEmployeeID() {
        return employeeID;
    }

    public String getEmployeeNAME() {
        return employeeNAME;
    }

    public String getEmployeeADDRESS() {
        return employeeADDRESS;
    }
    
    
    
    
}
