/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facades;

import entities.Employee;
import java.util.ArrayList;

/**
 *
 * @author Emil PC
 */
public interface EmployeeFacadeInterface {
    
    public Employee getEmployeeById(int id);
    
    public ArrayList<Employee> getEmployeesByName(String name);
    
    public ArrayList<Employee> getAllEmployees();
    
    public Employee getEmployeeWithHighestSalary();
    
    public Employee createEmployee(Employee emp);
    
    public void deleteEmployeeById(int id);
    
}
