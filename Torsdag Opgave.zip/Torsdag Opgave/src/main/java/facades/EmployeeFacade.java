   package facades;

import entities.Employee;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

/**
 *
 * Rename Class to a relevant name Add add relevant facade methods
 */
public class EmployeeFacade implements EmployeeFacadeInterface {

    private static EmployeeFacade instance;
    private static EntityManagerFactory emf;
    
    //Private Constructor to ensure Singleton
    EmployeeFacade() {
        this.emf = Persistence.createEntityManagerFactory("pu");
    }
    
    
    /**
     * 
     * @param _emf
     * @return an instance of this facade class.
     */
    public static EmployeeFacade getFacadeExample(EntityManagerFactory _emf) {
        if (instance == null) {
            emf = _emf;
            instance = new EmployeeFacade();
        }
        return instance;
    }

    private EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    @Override
    public Employee getEmployeeById(int id) {
        EntityManager em = emf.createEntityManager();
        try {
            Employee c = em.find(Employee.class, id);
            return c;
        } finally {
            em.close();
        }
    }

    @Override
    public ArrayList<Employee> getEmployeesByName(String name) {
        EntityManager em = emf.createEntityManager();
        try {
            Query q = em.createQuery("SELECT e FROM Employee e WHERE e.name = :name");
            q.setParameter("name", name);
            List list = new ArrayList<Employee>();
            for (int i = 0; i < q.getResultList().size(); ++i) {
                list.add(q.getResultList().get(i));
            }
            return (ArrayList<Employee>) list;
        } finally {
            em.close();
        }
    }

    @Override
    public ArrayList<Employee> getAllEmployees() {
        EntityManager em = emf.createEntityManager();
        try {
            Query q = em.createQuery("SELECT e FROM Employee e");
            List list = new ArrayList<Employee>();
            for (int i = 0; i < q.getResultList().size(); ++i) {
                list.add(q.getResultList().get(i));
            }
            return (ArrayList<Employee>) list;
        } finally {
            em.close();
        }
    }

    @Override
    public Employee getEmployeeWithHighestSalary() {
        EntityManager em = emf.createEntityManager();
        try {
            Query q = em.createQuery("SELECT MAX(e.salary) FROM Employee e");
            int max = (int) q.getSingleResult();
            q = em.createQuery("SELECT e FROM Employee e WHERE e.salary = :max");
            q.setParameter("max", max);
            List list = q.getResultList();
            Employee emp = (Employee) list.get(0);
            return emp;
        } finally {
            em.close();
        }
    }

    @Override
    public Employee createEmployee(Employee emp) {
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(emp);
            em.getTransaction().commit();
            return emp;
        } finally {
            em.close();
        }
    }

    @Override
    public void deleteEmployeeById(int id) {
        EntityManager em = emf.createEntityManager();
        EmployeeFacade ef = new EmployeeFacade();
        try {
            em.getTransaction().begin();
            em.remove(em.find(Employee.class, id));
            em.getTransaction().commit();
        } finally {
            em.close();
        }
    }

    
    
    
    
    
    
}
