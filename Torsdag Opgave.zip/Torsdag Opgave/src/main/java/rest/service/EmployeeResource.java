package rest.service;

import com.google.gson.Gson;
import dto.EmployeeDTO;
import entities.Employee;
import facades.EmployeeFacade;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriInfo;

@Path("employee")
public class EmployeeResource {

    @Context
    private UriInfo context;

    EntityManagerFactory emf;
    EmployeeFacade facade = EmployeeFacade.getFacadeExample(emf);

    @GET
    //@Produces(MediaType.APPLICATION_JSON)
    public String getString() {
        return "Hello from my first web service";
    }

    @GET
    @Path("/id/{id}")
    @Produces({MediaType.APPLICATION_JSON})
    public String getIdEmployees(@PathParam("id") int id) {
        Gson gs = new Gson();
        EmployeeDTO empDTO = new EmployeeDTO(facade.getEmployeeById(id));
        String empJson = gs.toJson(empDTO);
        return empJson;
    }

    @GET
    @Path("/all")
    @Produces({MediaType.APPLICATION_JSON})
    public String getAllEmployees() {
        Gson gs = new Gson();
        ArrayList<Employee> alEmp = facade.getAllEmployees();
        ArrayList<EmployeeDTO> alEmpDTO = new ArrayList<EmployeeDTO>();
        for (int i = 0; i < alEmp.size(); ++i) {
            EmployeeDTO empDTO = new EmployeeDTO(alEmp.get(i));
            alEmpDTO.add(empDTO);
        }
        String list = gs.toJson(alEmpDTO);
        return list;
    }

    @GET
    @Path("/highestpaid")
    @Produces({MediaType.APPLICATION_JSON})
    public String getHighestPaidEmployee() {
        Gson gs = new Gson();
        EmployeeDTO empDTO = new EmployeeDTO(facade.getEmployeeWithHighestSalary());
        String empJson = gs.toJson(empDTO);
        return empJson;
    }
    
    
    @GET
    @Path("/name/{name}")
    @Produces({MediaType.APPLICATION_JSON})
    public String getEmployeeByName(@PathParam("name") String name) {
        Gson gs = new Gson();
        ArrayList<Employee> sameName = facade.getEmployeesByName(name);
        ArrayList<EmployeeDTO> sameNameDTO = new ArrayList();
        
        for (int i = 0; i < sameName.size(); ++i) {
            EmployeeDTO empDTO = new EmployeeDTO(sameName.get(i));
            sameNameDTO.add(empDTO);
        }
        String empJson = gs.toJson(sameNameDTO);
        return empJson;
    }
    
    
}
