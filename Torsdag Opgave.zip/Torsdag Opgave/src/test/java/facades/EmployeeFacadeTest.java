/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facades;

import entities.Employee;
import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Emil PC
 */
public class EmployeeFacadeTest {
    
    public EmployeeFacadeTest() {
    }

    
    EmployeeFacade ef = new EmployeeFacade();
    
    @org.junit.BeforeClass
    public static void setUpClass() throws Exception {
        
    }


    /**
     * Test of getEmployeeById method, of class EmployeeFacade.
     */
    @Test
    public void testGetEmployeeById() {
        assertEquals("TestName1", ef.getEmployeeById(1).getName());
    }

    /**
     * Test of getEmployeesByName method, of class EmployeeFacade.
     */
    @Test
    public void testGetEmployeesByName() {
        assertEquals(2,ef.getEmployeesByName("TestName1").size());
    }

    /**
     * Test of getAllEmployees method, of class EmployeeFacade.
     */
    @Test
    public void testGetAllEmployees() {
        assertEquals(12,ef.getAllEmployees().size());
    }

    /**
     * Test of getEmployeeWithHighestSalary method, of class EmployeeFacade.
     */
    @Test
    public void testGetEmployeeWithHighestSalary() {
        int emp = ef.getEmployeeWithHighestSalary().getSalary();
        assertEquals(10000,emp);
    }

    /**
     * Test of createEmployee method, of class EmployeeFacade.
     */
    @Test
    public void testCreateEmployee() {
        Employee emp = new Employee("todelete","todelete",-1);
        ef.createEmployee(emp);
        ArrayList<Employee> emp2 = ef.getEmployeesByName("todelete");
        String name = emp2.get(0).getName();
        int id = emp2.get(0).getId();
        ef.deleteEmployeeById(id);
        assertEquals("todelete",name);
        
    }
    


}
