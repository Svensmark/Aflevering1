package rest.service;

import BankCustomerDTO.CustomerDTO;
import com.google.gson.Gson;
import entities.BankCustomer;
import facades.CustomerFacade;
import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


@Path("bankcustomer")
public class BankCustomerResource {

    EntityManagerFactory emf; 
    CustomerFacade facade =  new CustomerFacade();

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public String demo() {
        return "{\"msg\":\"succes\"}";
    }

    @POST
    @Consumes({MediaType.APPLICATION_JSON})
    public void create(BankCustomer entity) {
        throw new UnsupportedOperationException();
    }
    
    @GET
    @Path("/id/{id}")
    @Produces({MediaType.APPLICATION_JSON})
    public String getIdEmployees(@PathParam("id") int id) {
        Gson gs = new Gson();
        CustomerDTO dto = facade.getCustomerByID(id);
        String dtoJson = gs.toJson(dto);
        return dtoJson;
    }
        
    @GET
    @Path("/all")
    @Produces({MediaType.APPLICATION_JSON})
    public String getAllEmployees() {
        Gson gs = new Gson();
        ArrayList<BankCustomer> bc = (ArrayList<BankCustomer>) facade.getAllBankCustomers();
        String dtoJson = gs.toJson(bc);
        return dtoJson;
    }
    
    @GET
    @Path("/populate")
    @Produces({MediaType.APPLICATION_JSON})
    public String populate() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
        EntityManager em = emf.createEntityManager(); 
        em.getTransaction().begin();
        BankCustomer bc1 = new BankCustomer("FirstName1","LastName1","AccountNumber111",2500.50,50,"This is the first bank customer");
        BankCustomer bc5 = new BankCustomer("FirstName1","LastName1","AccountNumber111",2500.50,50,"This is the first bank customer");
        BankCustomer bc2 = new BankCustomer("FirstName2","LastName2","AccountNumber222",3499.99,10,"This is the second and average bank customer");
        BankCustomer bc3 = new BankCustomer("FirstName3","LastName3","AccountNumber333",1499.00,500,"This is the thirds and poor bank customer");
        BankCustomer bc4 = new BankCustomer("FirstName4","LastName4","AccountNumber444",39929,1,"This is the fourth and perfectly rich bank customer");
        em.persist(bc1);
        em.persist(bc2);
        em.persist(bc3);
        em.persist(bc4);
        em.persist(bc5);
        em.getTransaction().commit();
        em.close();
        emf.close();
        
        return "Your database has been populated";
    }
}
