
package entities;

import facades.CustomerFacade;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class MakeTestData {
    
    public static void main(String[] args) {
        /*
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
        EntityManager em = emf.createEntityManager();
        
        em.getTransaction().begin();
        
        BankCustomer bc1 = new BankCustomer("FirstName1","LastName1","AccountNumber111",2500.50,50,"This is the first bank customer");
        BankCustomer bc2 = new BankCustomer("FirstName2","LastName2","AccountNumber222",3499.99,10,"This is the second and average bank customer");
        BankCustomer bc3 = new BankCustomer("FirstName3","LastName3","AccountNumber333",1499.00,500,"This is the thirds and poor bank customer");
        BankCustomer bc4 = new BankCustomer("FirstName4","LastName4","AccountNumber444",39929,1,"This is the fourth and perfectly rich bank customer");
        */
        
        CustomerFacade cf = new CustomerFacade();
        System.out.println(cf.getCustomerByID(1).getFullName());
        System.out.println(cf.getCustomerByID(2).getFullName());
        System.out.println(cf.getCustomerByID(3).getFullName());
        System.out.println(cf.getCustomerByID(4).getFullName());
        
        System.out.println(cf.getCustomerByName("FirstName1", "LastName1").get(0).getFullName());
        System.out.println(cf.getAllBankCustomers());
        cf.deleteBankCustomer(5);
    }
    
}
