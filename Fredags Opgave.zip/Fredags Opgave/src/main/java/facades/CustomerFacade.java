package facades;

import BankCustomerDTO.CustomerDTO;
import entities.BankCustomer;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

/**
 *
 * Rename Class to a relevant name Add add relevant facade methods
 */
public class CustomerFacade implements CustomerFacadeInterface {

    private static CustomerFacade instance;
    private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");

    //Private Constructor to ensure Singleton
    public CustomerFacade() {
    }

    /**
     *
     * @param _emf
     * @return an instance of this facade class.
     */
    public static CustomerFacade getFacadeExample(EntityManagerFactory _emf) {
        if (instance == null) {
            emf = _emf;
            instance = new CustomerFacade();
        }
        return instance;
    }

    private EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    @Override
    public CustomerDTO getCustomerByID(int id) {
        EntityManager em = emf.createEntityManager();
        try {
            BankCustomer c = em.find(BankCustomer.class, id);
            return new CustomerDTO(c);
        } finally {
            em.close();
        }
    }

    @Override
    public List<CustomerDTO> getCustomerByName(String fname, String lname) {
        EntityManager em = emf.createEntityManager();
        try {
            Query q = em.createQuery("SELECT c FROM BankCustomer c WHERE c.firstName = :fname AND c.lastName = :lname");
            q.setParameter("fname", fname);
            q.setParameter("lname", lname);
            List list = new ArrayList<CustomerDTO>();
            for (int i = 0; i < q.getResultList().size(); ++i) {
                BankCustomer bc = (BankCustomer) q.getResultList().get(i);
                list.add(new CustomerDTO(bc));
            }
            return list;
        } finally {
            em.close();
        }
    }

    @Override
    public BankCustomer addCustomer(BankCustomer customer) {
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(customer);
            em.getTransaction().commit();
            return customer;
        } finally {
            em.close();
        }
    }

    @Override
    public List<BankCustomer> getAllBankCustomers() {
        EntityManager em = emf.createEntityManager();
        try {
            Query q = em.createQuery("SELECT c FROM BankCustomer c");
            List list = new ArrayList<BankCustomer>();
            for (int i = 0; i < q.getResultList().size(); ++i) {
                list.add(q.getResultList().get(i));
            }
            return list;
        } finally {
            em.close();
        }
    }

    @Override
    public void deleteBankCustomer(int id) {
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            em.remove(em.find(BankCustomer.class, id));
            em.getTransaction().commit();
        } finally {
            em.close();
        }
    }

}
