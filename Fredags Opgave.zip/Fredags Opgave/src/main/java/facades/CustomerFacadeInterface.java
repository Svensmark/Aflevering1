/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facades;

import BankCustomerDTO.CustomerDTO;
import entities.BankCustomer;
import java.util.List;

/**
 *
 * @author Emil PC
 */
public interface CustomerFacadeInterface {
    
    public CustomerDTO getCustomerByID(int id);
    public List<CustomerDTO> getCustomerByName(String fname, String lname);
    public BankCustomer addCustomer(BankCustomer customer);
    public List<BankCustomer> getAllBankCustomers();
    
    public void deleteBankCustomer(int id);
    
    
}
