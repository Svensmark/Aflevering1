 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facades;

import BankCustomerDTO.CustomerDTO;
import entities.BankCustomer;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManagerFactory;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Emil PC
 */
public class CustomerFacadeTest {
    
    public CustomerFacadeTest() {
    }
    
    CustomerFacade cf = new CustomerFacade();

/*
    /**
     * Test of getCustomerByID method, of class CustomerFacade.
     
    @Test
    public void testGetCustomerByID() {
        assertEquals("FirstName3 LastName3",cf.getCustomerByID(1).getFullName());
    }

    /**
     * Test of getCustomerByName method, of class CustomerFacade.
     
    @Test
    public void testGetCustomerByName() {
        CustomerDTO c = (CustomerDTO) cf.getCustomerByName("FirstName3", "LastName3").get(0);
        assertEquals(1,c.getCustomerID());
    }

    /**
     * Test of addCustomer method, of class CustomerFacade.
     
    @Test
    public void testAddCustomer() {
        BankCustomer bcexp = new BankCustomer("todelete","todelete","todelete",-1,-1,"todelete");
        cf.addCustomer(bcexp);
        CustomerDTO bcres = (CustomerDTO) cf.getCustomerByName("todelete", "todelete").get(0);
        cf.deleteBankCustomer(bcexp.getId());
        assertEquals("todelete todelete", bcres.getFullName());
    }

    /**
     * Test of getAllBankCustomers method, of class CustomerFacade.
     
    @Test
    public void testGetAllBankCustomers() {
        ArrayList<BankCustomer> al = (ArrayList<BankCustomer>) cf.getAllBankCustomers();
        assertEquals(4,al.size());
    }
    */
}
